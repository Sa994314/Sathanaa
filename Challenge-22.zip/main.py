class Player: 
 def play(self):
  print("The player is playing cricket.")

class Batsman(Player):
  def play(self):
   print("The Batsman is batting.")

class Bowler(Player):
  def play(self):
   print("The Bowler us bowling.")

batsman=Batsman()
bowler=Bowler()

batsman.play()
bowler.play()o

   